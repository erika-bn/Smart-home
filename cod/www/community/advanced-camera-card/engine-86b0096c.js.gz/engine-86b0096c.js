const e=1e4;export{e as C};
